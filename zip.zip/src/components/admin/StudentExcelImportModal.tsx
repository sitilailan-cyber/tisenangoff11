import React, { useState, useRef } from 'react';
import * as XLSX from 'xlsx';
import { Modal } from '../common/Modal';
import { ClassRoom, User } from '../../types';
import { storage } from '../../services/storage';
import { validateFileSize } from '../../utils/fileCompressor';
import {
  FileSpreadsheet,
  Download,
  UploadCloud,
  CheckCircle2,
  AlertTriangle,
  Trash2,
  Users,
  Plus,
  ArrowRight,
  FileCheck,
} from 'lucide-react';

interface StudentExcelImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  classes: ClassRoom[];
  existingUsers: User[];
  onSuccess: (count: number) => void;
}

interface ParsedStudentRow {
  id: string;
  fullName: string;
  username: string;
  password: string;
  classId: string;
  classNameLabel: string;
  isValid: boolean;
  warnings: string[];
}

export const StudentExcelImportModal: React.FC<StudentExcelImportModalProps> = ({
  isOpen,
  onClose,
  classes,
  existingUsers,
  onSuccess,
}) => {
  const [file, setFile] = useState<File | null>(null);
  const [fileName, setFileName] = useState<string>('');
  const [defaultClassId, setDefaultClassId] = useState<string>(classes[0]?.id || '');
  const [parsedRows, setParsedRows] = useState<ParsedStudentRow[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Download official Excel template
  const handleDownloadTemplate = () => {
    try {
      const sampleClass1 = classes[0]?.className || 'XII-1';
      const sampleClass2 = classes[1]?.className || classes[0]?.className || 'XII-2';

      const templateData = [
        {
          'Nama Lengkap': 'Ahmad Fauzi Rahman',
          'Username': 'ahmad.fauzi',
          'Password': 'siswa123',
          'Kelas': sampleClass1,
        },
        {
          'Nama Lengkap': 'Dewi Lestari Putri',
          'Username': 'dewi.lestari',
          'Password': 'siswa123',
          'Kelas': sampleClass1,
        },
        {
          'Nama Lengkap': 'Rian Hidayat Saputra',
          'Username': 'rian.hidayat',
          'Password': 'siswa123',
          'Kelas': sampleClass2,
        },
        {
          'Nama Lengkap': 'Siti Nurhaliza',
          'Username': 'siti.nurhaliza',
          'Password': 'siswa123',
          'Kelas': sampleClass2,
        },
      ];

      const worksheet = XLSX.utils.json_to_sheet(templateData);
      worksheet['!cols'] = [
        { wch: 28 }, // Nama Lengkap
        { wch: 18 }, // Username
        { wch: 14 }, // Password
        { wch: 12 }, // Kelas
      ];

      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Data Murid');
      XLSX.writeFile(workbook, 'Template_Input_Murid_TI_SENANG.xlsx');
    } catch (err: any) {
      setErrorMsg('Gagal mengunduh template Excel: ' + (err.message || 'Error tidak diketahui'));
    }
  };

  // Helper to match class name from text
  const matchClassId = (classText: string): { id: string; name: string } => {
    if (!classText || !classText.trim()) {
      const fallback = classes.find((c) => c.id === defaultClassId) || classes[0];
      return { id: fallback?.id || '', name: fallback?.className || 'XII-1' };
    }

    const cleanInput = classText.toString().trim().toLowerCase().replace(/[\s\-_]/g, '');
    
    // Direct match
    const found = classes.find((c) => {
      const cleanClassName = c.className.toLowerCase().replace(/[\s\-_]/g, '');
      return cleanClassName === cleanInput;
    });

    if (found) {
      return { id: found.id, name: found.className };
    }

    // Partial match
    const partial = classes.find((c) => {
      const cleanClassName = c.className.toLowerCase().replace(/[\s\-_]/g, '');
      return cleanInput.includes(cleanClassName) || cleanClassName.includes(cleanInput);
    });

    if (partial) {
      return { id: partial.id, name: partial.className };
    }

    // Fallback to default class
    const fallback = classes.find((c) => c.id === defaultClassId) || classes[0];
    return { id: fallback?.id || '', name: fallback?.className || classText };
  };

  // Process raw Excel data into student rows
  const processExcelFile = (uploadedFile: File) => {
    setErrorMsg(null);

    // Batasi file maksimal 2MB, jika lebih dari 2MB maka aplikasi menolak
    const sizeCheck = validateFileSize(uploadedFile);
    if (!sizeCheck.valid) {
      setErrorMsg(sizeCheck.error || 'Ukuran file melebihi batas maksimal 2MB. Aplikasi menolak file ini.');
      alert(sizeCheck.error || 'Ukuran file melebihi batas maksimal 2MB. Aplikasi menolak file ini.');
      return;
    }

    setIsProcessing(true);
    setFileName(uploadedFile.name);
    setFile(uploadedFile);

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });

        if (!workbook.SheetNames || workbook.SheetNames.length === 0) {
          throw new Error('File Excel tidak memiliki lembar kerja (worksheet).');
        }

        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const rawJson = XLSX.utils.sheet_to_json<Record<string, any>>(worksheet, { defval: '' });

        if (!rawJson || rawJson.length === 0) {
          throw new Error('File Excel kosong atau tidak memiliki baris data.');
        }

        const existingUsernames = new Set(existingUsers.map((u) => u.username.toLowerCase()));
        const seenInFile = new Set<string>();

        const parsed: ParsedStudentRow[] = rawJson
          .map((row, index) => {
            // Find keys regardless of exact casing or punctuation
            const keys = Object.keys(row);
            const findValue = (possibleNames: string[]): string => {
              for (const name of possibleNames) {
                const matchedKey = keys.find(
                  (k) => k.trim().toLowerCase().replace(/[\s\-_]/g, '') === name.toLowerCase().replace(/[\s\-_]/g, '')
                );
                if (matchedKey && row[matchedKey] !== undefined && row[matchedKey] !== null) {
                  return String(row[matchedKey]).trim();
                }
              }
              return '';
            };

            const fullName = findValue(['namalengkap', 'namasiswa', 'namamurid', 'nama', 'name', 'fullname']);
            let username = findValue(['username', 'user', 'nisn', 'id', 'nis']);
            const password = findValue(['password', 'katasandi', 'pass', 'pin']) || 'siswa123';
            const rawClass = findValue(['kelas', 'class', 'rombel', 'ruang', 'tingkat']);

            if (!fullName) return null; // Skip empty header/empty row

            // Generate username if not provided
            if (!username) {
              const clean = fullName.toLowerCase().replace(/[^a-z0-9]/g, '');
              username = clean || `siswa${index + 1}`;
            } else {
              username = username.toLowerCase().replace(/[^a-z0-9._-]/g, '');
            }

            const warnings: string[] = [];

            if (existingUsernames.has(username.toLowerCase())) {
              warnings.push(`Username "${username}" sudah ada di sistem (akan disesuaikan otomatis saat disimpan)`);
            } else if (seenInFile.has(username.toLowerCase())) {
              warnings.push(`Username "${username}" duplikat di dalam file ini`);
            }
            seenInFile.add(username.toLowerCase());

            const matchedClass = matchClassId(rawClass);

            return {
              id: `row-${Date.now()}-${index}`,
              fullName,
              username,
              password,
              classId: matchedClass.id,
              classNameLabel: matchedClass.name,
              isValid: fullName.length > 0,
              warnings,
            };
          })
          .filter((item): item is ParsedStudentRow => item !== null);

        if (parsed.length === 0) {
          throw new Error('Tidak ditemukan baris murid yang valid dalam file Excel.');
        }

        setParsedRows(parsed);
      } catch (err: any) {
        setErrorMsg(err.message || 'Terjadi kesalahan saat membaca file Excel.');
        setParsedRows([]);
      } finally {
        setIsProcessing(false);
      }
    };

    reader.onerror = () => {
      setErrorMsg('Gagal membaca file.');
      setIsProcessing(false);
    };

    reader.readAsArrayBuffer(uploadedFile);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processExcelFile(e.target.files[0]);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processExcelFile(e.dataTransfer.files[0]);
    }
  };

  const handleRowChange = (id: string, field: keyof ParsedStudentRow, value: any) => {
    setParsedRows((prev) =>
      prev.map((r) => {
        if (r.id === id) {
          const updated = { ...r, [field]: value };
          if (field === 'classId') {
            const cls = classes.find((c) => c.id === value);
            updated.classNameLabel = cls ? cls.className : 'XII-1';
          }
          return updated;
        }
        return r;
      })
    );
  };

  const handleRemoveRow = (id: string) => {
    setParsedRows((prev) => prev.filter((r) => r.id !== id));
  };

  const handleAddEmptyRow = () => {
    const newIndex = parsedRows.length + 1;
    const targetClass = classes.find((c) => c.id === defaultClassId) || classes[0];
    const newRow: ParsedStudentRow = {
      id: `manual-row-${Date.now()}`,
      fullName: '',
      username: `siswa${newIndex}`,
      password: 'siswa123',
      classId: targetClass?.id || '',
      classNameLabel: targetClass?.className || 'XII-1',
      isValid: false,
      warnings: [],
    };
    setParsedRows((prev) => [...prev, newRow]);
  };

  // Save all valid rows to storage
  const handleSaveToApplication = () => {
    const validRows = parsedRows.filter((r) => r.fullName && r.fullName.trim().length > 0);
    if (validRows.length === 0) {
      setErrorMsg('Tidak ada data murid yang valid untuk diimpor.');
      return;
    }

    try {
      const count = storage.addStudentsBatch(
        validRows.map((r) => ({
          fullName: r.fullName,
          username: r.username,
          password: r.password || 'siswa123',
          classId: r.classId || defaultClassId || classes[0]?.id,
        }))
      );

      onSuccess(count);
      handleReset();
      onClose();
    } catch (err: any) {
      setErrorMsg('Gagal menyimpan data ke aplikasi: ' + (err.message || 'Error tidak diketahui'));
    }
  };

  const handleReset = () => {
    setFile(null);
    setFileName('');
    setParsedRows([]);
    setErrorMsg(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={() => {
        handleReset();
        onClose();
      }}
      title="Input & Import Data Murid dari Excel"
      subtitle="Unggah file Excel untuk mengisi dan menambahkan akun murid secara otomatis ke aplikasi"
      maxWidth="2xl"
    >
      <div className="space-y-4 max-h-[75vh] overflow-y-auto pr-1">
        {/* Step 1 & 2 Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {/* Template Download Card */}
          <div className="p-3.5 rounded-xl bg-gradient-to-br from-emerald-50 to-teal-50 border border-emerald-200/80 flex flex-col justify-between shadow-xs">
            <div>
              <div className="flex items-center gap-2 mb-1.5 text-emerald-900 font-bold text-xs">
                <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                <span>Format File Excel</span>
              </div>
              <p className="text-[11px] text-emerald-800/80 leading-relaxed mb-2.5">
                Gunakan template resmi berisi kolom <strong>Nama Lengkap, Username, Password, Kelas</strong> agar data terbaca 100% otomatis.
              </p>
            </div>
            <button
              type="button"
              onClick={handleDownloadTemplate}
              className="w-full py-2 px-3 rounded-lg bg-white hover:bg-emerald-100/60 border border-emerald-300 text-emerald-800 font-bold text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-2xs"
            >
              <Download className="w-3.5 h-3.5 text-emerald-600" />
              <span>Unduh Template Excel (.xlsx)</span>
            </button>
          </div>

          {/* Default Class Configuration */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex flex-col justify-between shadow-xs">
            <div>
              <div className="flex items-center gap-2 mb-1.5 text-slate-800 font-bold text-xs">
                <Users className="w-4 h-4 text-blue-600" />
                <span>Kelas Default</span>
              </div>
              <p className="text-[11px] text-slate-600 leading-relaxed mb-2">
                Pilihan kelas jika baris di Excel tidak mencantumkan kelas:
              </p>
            </div>
            <select
              value={defaultClassId}
              onChange={(e) => setDefaultClassId(e.target.value)}
              className="w-full h-9 px-3 rounded-lg border border-slate-300 bg-white text-xs font-semibold text-slate-800 outline-hidden focus:border-blue-500 focus:ring-1 focus:ring-blue-400"
            >
              {classes.map((cls) => (
                <option key={cls.id} value={cls.id}>
                  {cls.className}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Upload Dropzone */}
        {!file && (
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setIsDragOver(true);
            }}
            onDragLeave={() => setIsDragOver(false)}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-2xl p-6 text-center cursor-pointer transition-all ${
              isDragOver
                ? 'border-emerald-500 bg-emerald-50/70 scale-99'
                : 'border-slate-300 hover:border-emerald-400 bg-slate-50/50 hover:bg-emerald-50/30'
            }`}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".xlsx, .xls, .csv"
              onChange={handleFileChange}
              className="hidden"
            />
            <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto mb-2.5 shadow-xs">
              <UploadCloud className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-bold text-slate-800 mb-1">
              Klik atau Seret File Excel ke Sini
            </h4>
            <p className="text-xs text-slate-500 max-w-sm mx-auto mb-2">
              Mendukung format Microsoft Excel (<strong>.xlsx</strong>, <strong>.xls</strong>) atau file <strong>.csv</strong>
            </p>
            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-100/70 px-2.5 py-0.5 rounded-full">
              Data langsung terisi otomatis ke tabel setelah dipilih
            </span>
          </div>
        )}

        {/* Error message */}
        {errorMsg && (
          <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0 text-red-500" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Parsed Results Section */}
        {parsedRows.length > 0 && (
          <div className="space-y-3">
            {/* Header Status Bar */}
            <div className="p-3 rounded-xl bg-emerald-50/90 border border-emerald-200 flex flex-wrap items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-2">
                <FileCheck className="w-4 h-4 text-emerald-600" />
                <span className="font-bold text-emerald-950">
                  File: <span className="font-mono">{fileName}</span>
                </span>
                <span className="px-2 py-0.5 rounded-md bg-emerald-200/80 text-emerald-900 font-bold text-[11px]">
                  {parsedRows.length} Murid Terbaca
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleAddEmptyRow}
                  className="px-2.5 py-1 rounded-lg bg-white border border-emerald-300 text-emerald-800 hover:bg-emerald-100/70 font-semibold text-xs flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <Plus className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Tambah Baris</span>
                </button>
                <button
                  type="button"
                  onClick={handleReset}
                  className="px-2.5 py-1 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold text-xs cursor-pointer transition-colors"
                >
                  Ganti File
                </button>
              </div>
            </div>

            {/* Editable Table */}
            <div className="border border-slate-200 rounded-xl overflow-hidden shadow-xs">
              <div className="overflow-x-auto max-h-64">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200 sticky top-0 z-10">
                    <tr>
                      <th className="py-2.5 px-3 w-10 text-center">No</th>
                      <th className="py-2.5 px-3 min-w-[160px]">Nama Lengkap</th>
                      <th className="py-2.5 px-3 min-w-[120px]">Username</th>
                      <th className="py-2.5 px-3 min-w-[100px]">Password</th>
                      <th className="py-2.5 px-3 min-w-[110px]">Kelas</th>
                      <th className="py-2.5 px-3 w-14 text-center">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 bg-white">
                    {parsedRows.map((row, idx) => (
                      <tr key={row.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-2 px-3 text-center text-slate-500 font-medium">{idx + 1}</td>
                        <td className="py-2 px-3">
                          <input
                            type="text"
                            value={row.fullName}
                            onChange={(e) => handleRowChange(row.id, 'fullName', e.target.value)}
                            placeholder="Nama Lengkap..."
                            className="w-full h-8 px-2 rounded-lg border border-slate-200 focus:border-blue-500 focus:ring-1 focus:ring-blue-400 font-semibold text-slate-800 bg-white"
                          />
                        </td>
                        <td className="py-2 px-3">
                          <input
                            type="text"
                            value={row.username}
                            onChange={(e) => handleRowChange(row.id, 'username', e.target.value)}
                            placeholder="username"
                            className="w-full h-8 px-2 rounded-lg border border-slate-200 focus:border-blue-500 focus:ring-1 focus:ring-blue-400 font-mono text-slate-700 bg-white"
                          />
                        </td>
                        <td className="py-2 px-3">
                          <input
                            type="text"
                            value={row.password}
                            onChange={(e) => handleRowChange(row.id, 'password', e.target.value)}
                            placeholder="siswa123"
                            className="w-full h-8 px-2 rounded-lg border border-slate-200 focus:border-blue-500 focus:ring-1 focus:ring-blue-400 font-mono text-slate-600 bg-white text-[11px]"
                          />
                        </td>
                        <td className="py-2 px-3">
                          <select
                            value={row.classId}
                            onChange={(e) => handleRowChange(row.id, 'classId', e.target.value)}
                            className="w-full h-8 px-2 rounded-lg border border-slate-200 bg-white font-semibold text-slate-800 text-xs focus:border-blue-500 focus:ring-1 focus:ring-blue-400"
                          >
                            {classes.map((c) => (
                              <option key={c.id} value={c.id}>
                                {c.className}
                              </option>
                            ))}
                          </select>
                        </td>
                        <td className="py-2 px-3 text-center">
                          <button
                            type="button"
                            onClick={() => handleRemoveRow(row.id)}
                            title="Hapus baris ini"
                            className="p-1.5 rounded-lg text-rose-500 hover:text-rose-700 hover:bg-rose-50 transition-colors cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Warnings list if any */}
            {parsedRows.some((r) => r.warnings.length > 0) && (
              <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-[11px] space-y-1">
                <div className="font-bold flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                  <span>Catatan Validasi Otomatis:</span>
                </div>
                <p className="text-amber-700">
                  Jika ada username yang serupa dengan akun terdaftar, sistem akan otomatis menambahkan nomor unik di belakang username murid saat disimpan ke aplikasi.
                </p>
              </div>
            )}
          </div>
        )}

        {/* Action Buttons */}
        <div className="pt-2 border-t border-slate-200 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => {
              handleReset();
              onClose();
            }}
            className="px-4 py-2.5 rounded-xl border border-slate-300 hover:bg-slate-100 text-slate-700 font-bold text-xs transition-colors cursor-pointer"
          >
            Batal
          </button>

          <button
            type="button"
            disabled={parsedRows.length === 0 || isProcessing}
            onClick={handleSaveToApplication}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold text-xs shadow-md hover:shadow-lg transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed active:scale-98"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>
              {parsedRows.length > 0
                ? `Simpan ${parsedRows.length} Murid ke Aplikasi`
                : 'Pilih File Terlebih Dahulu'}
            </span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </Modal>
  );
};
